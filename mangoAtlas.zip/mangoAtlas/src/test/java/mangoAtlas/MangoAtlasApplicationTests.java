package mangoAtlas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MangoAtlasApplicationTests {

	@Test
	void contextLoads() {
	}

}
