package mangoAtlas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MangoAtlasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MangoAtlasApplication.class, args);
	}

}
